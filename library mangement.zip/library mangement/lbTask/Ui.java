package lbTask;

public class Ui {
	
	Scanner sc = new Scanner(System.in);
	LibraryManagement lb = new LibraryManagement()
			public static void main(String[] args) {
		System.out.println("Enter the book id: ");
		int bookid = sc.nextInt();
		System.out.println("Enter the book name: ");
		String bookname = sc.nextLine();
		System.out.println("Enter the author name: ");
	    String author = sc.nextLine();
		System.out.println("Enter the price: ");
		double price= sc.nextDouble();
		
	
	}
	
	    
}
