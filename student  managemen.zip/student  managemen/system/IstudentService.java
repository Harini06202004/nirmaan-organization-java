package student.management.system;

import java.util.Set;

public interface IstudentService {

	public Student addStudent();
	public void getStudents(Set<Student> set);
	public Student getStudentById (Set <Student>set);
	public Set<Student> putStudent(Set<Student>set);
	public Set<Student> deleteStudentById(Set <Student>set);
	
	
	    
}
