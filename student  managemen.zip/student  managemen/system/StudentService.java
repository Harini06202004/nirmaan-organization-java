package student.management.system;

import java.util.Scanner;
import java.util.Set;

public class StudentService implements IstudentService {
	Scanner sc = new Scanner(System.in);

	@Override
	public Student addStudent() {
		Student std = new Student();
		
		System.out.println("Enter the Student Id : ");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the Student Name :");
		String name = sc.nextLine();
		System.out.println("Enter the Student Roll No : ");
		int rollno = sc.nextInt();
		System.out.println("Enter the fees:  ");
		int fees = sc.nextInt();
		return std = new Student(id, rollno, name, fees);
	
	}

	@Override
	public void getStudents(Set<Student> set) {
		System.out.println(set);
		
	}

	@Override
	public Student getStudentById(Set<Student> set) {
	
		System.out.println("Enter the ID of the student: ");
		int id = sc.nextInt();
		
		for(Student stud:set) {
			if(id==stud.getId()) {
				return stud;
		
		
	        }
        }
		return null;
}

	@Override
	public Set<Student> putStudent(Set<Student> set) {
		System.out.println("Enter the student ID for upadate: ");
		int id = sc.nextInt();
		sc.nextLine();
		
		for(Student std :set) {
			if(std.getId()==id) {
				System.out.println("Enter the Student Name :");
				String name = sc.nextLine();
				System.out.println("Enter the Student Roll No : ");
				int rollno = sc.nextInt();
				System.out.println("Enter the fees: ");
				int fees = sc.nextInt();
				std.setName(name);
				std.setRollno(rollno);
				std.setFees(fees);
				
			}
		}
		
		
        return set;
	}

	@Override
	public Set<Student> deleteStudentById(Set<Student> set) {
		System.out.println("Enter the Student Id for delete : ");
		int id = sc.nextInt();

		for (Student std : set) {
			if (id == std.getId()) {
				set.remove(std);
				return set;
			}
		}

		return set;
	
		
	
	}

}
