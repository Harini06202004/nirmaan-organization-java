package student.management.system;

import java.util.Objects;

public class Student implements Comparable<Student>{
	private int id;
	private int rollno;
	private String name;
	private int fees;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	public Student(int id, int rollno, String name, int fees) {
		super();
		this.id = id;
		this.rollno = rollno;
		this.name = name;
		this.fees = fees;
	}
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", rollno=" + rollno + ", name=" + name + ", fees=" + fees + "]";
	}
	@Override
	public int compareTo(Student std) {
		if(this.id < std.getId()) {
			return -1;
			
		}else if (this.id > std.getId()) {
			return 1;
			
		}else {
			return 0;
		}
		
	}
	

}
