package student.management.system;

import java.util.Scanner;
import java.util.TreeSet;

public class UserInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Student std = new Student();
		StudentService ss = new StudentService();
		TreeSet<Student> ts = new TreeSet<Student>();
		
		while(true) {
			System.out.println("Enter your choice: ");
	        System.out.println("1. Add student: \n 2. Print all the student details: \n 3.Get student detail by ID: \n 4.Update student details:  \n 5.Delete student details by ID:");
	        int key = sc.nextInt();
	        
	        
	        if(key==1) {
	        	ts.add(ss.addStudent());
	        }else if(key==2) {
	        	ss.getStudents(ts);
	        }else if(key==3) {
	        	System.out.println(ss.getStudentById(ts));
	        }else if(key==4) {
	        	ss.putStudent(ts);
	        	
	        }else if(key==5) {
	        	ss.deleteStudentById(ts);
	        }
	        }
	}
}
