package day10;

import java.util.Scanner;

public class UI {
	public static void main(String[] args) {
		Calculator calc = new Calculator();
		
		Scanner Sc = new Scanner(System.in);
		System.out.println("enter number1 =");
		int number1 = Sc.nextInt();
		System.out.println("enter number2 =");
		int number2 = Sc.nextInt();
		calc.add(number1, number2);
		calc.mul(number1, number2);
		calc.sub(number1, number2);
	}

}
