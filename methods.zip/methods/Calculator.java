package day10;

public class Calculator {
	void add(int number1,int number2) {
		System.out.println("Addition= " +(number1 + number2));
		
	}
	void sub(int number1, int number2) {
		System.out.println("Subtraction= "+ (number1 - number2));
	}
	
	void mul(int number1 ,int number2) {
		System.out.println("multiplication= "+ (number1 * number2));
	}
	
	
}

