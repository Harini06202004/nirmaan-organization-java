package day10;

public class MethodsInJava {
	String name;
	long phoneNum;
	double salary;
	
	void display() {
		System.out.println("empname= " + name);
		System.out.println("empphonenum= " +phoneNum);
		System.out.println("empsalary= " +salary);
	}
	public static void main(String[] args) {
		MethodsInJava emp = new MethodsInJava();
		emp.name="harini";
		emp.phoneNum =3454545;
		emp.salary=22333.90;
		emp.display();

       MethodsInJava emp2 = new MethodsInJava();
       emp2.name="hema";
       emp2.phoneNum= 628827287;
       emp2.salary= 662728.98;
       emp2.display();
		
		
		
	}

}
