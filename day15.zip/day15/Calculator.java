package day15;

import java.util.Scanner;

public class Calculator {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		int num1  = sc.nextInt();
		System.out.println("Enter the second number");
		int num2  = sc.nextInt();
		
		System.out.println("press 1 for addition");
		System.out.println("press 2 for subtraction");
		System.out.println("press 3 for multiplication");
		System.out.println("press 4 for division");
		System.out.println("press 5 for modules");
		int key = sc.nextInt();
		
		switch(key) {
		case 1:{
			System.out.println("ADD: "+ (num1 + num2));
			break;
		}
		case 2:{
			System.out.println("SUB: "+( num1 - num2));
			break;
		}
		case 3:{
			System.out.println("MUL: "+(num1* num2));
			break;
		}
		case 4:{
			System.out.println("DIV:"+(num1/num2));
			break;
		}
		case 5:{
			System.out.println("MOD: "+ (num1%num2));
			break;
		}
		}
		
		
	}
}
		
		
		
 		
