package day12;

public class ConstructorInJava {
	public void add() {
		System.out.println("empty value" );
	}
	public void add(int a, int b) {
		System.out.println("the values are: " +(a+b) );
	}
	public void add(int a, int b, int c) {
		System.out.println("the values are: "+(a+b+c));
	}
	public static void main(String[] args) {
		ConstructorInJava con = new ConstructorInJava();
		con.add();
		con.add(100,130);
		con.add(20, 30, 49);
		
				}
	
}
