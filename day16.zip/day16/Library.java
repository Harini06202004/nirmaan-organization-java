package day16;

public class Library {
	String bookname;
	String authorname;
	int ID;
	float price;
	
	public static void main(String[] args) {
		Library lib1 = new Library();
		lib1.bookname = "To kill a mockingbird";
		lib1.authorname= "harper lee";
		lib1.ID= 01;
		lib1.price=500;
		
		Library lib2 = new Library();
		lib2.bookname=" The alchemist";
		lib2.authorname="paulo ";
		lib2.ID= 02;
		lib2.price=600;
		
		Library lib3 = new Library();
		lib3.bookname="rivers";
		lib3.authorname="orwell ";
		lib3.ID= 03;
		lib3.price=400;
		
		Library lib4 = new Library();
		lib4.bookname="The great gatsby";
		lib4.authorname="scott ";
		lib4.ID= 04;
		lib4.price=900;
		
		Library lib5 = new Library();
		lib5.bookname="pride and prejudice";
		lib5.authorname= "jane austen" ;
		lib5.ID= 04;
		lib5.price= 800;
		
		System.out.println("AUTHOR NAME OF BOOK 5: "+ lib5.authorname);
		System.out.println("ID OF BOOK 4: " + lib4.ID);
		System.out.println("PRICE OF BOOK 3:  "+ lib3.price);
		System.out.println("NAME OF BOOK 1:  "+ lib1.bookname);
		System.out.println("NAME OF BOOK 2:  " + lib2.bookname);
		
		
		
		
		
	}
	}

