package day11;

public class Employee {
	private String name;
	private int rollNo;
	private double salary;
	private long number;
	
	public void setName(String EmployeeName) {
		name = EmployeeName;
		
	}
	public String getName() {
		return name;
	}
	public void setRollNo(int EmployeeRollNo) {
		rollNo =EmployeeRollNo;
	}
    public int getrollNo() {
    	return rollNo;
    }
    public void setSalary(double EmployeeSalary) {
    	salary = EmployeeSalary;
    }
    public double getsalary() {
    	return salary;
    }
    public void setNumber(long EmployeeNumber) {
    	number = EmployeeNumber;
    }
    public long getnumber() {
    	return number;
    }
}