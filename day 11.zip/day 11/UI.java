package day11;

public class UI {
	public static void main(String[] args) {
		Employee val = new Employee();
		
		val.setName("Harini");
		val.setRollNo(22);
		val.setSalary(200000);
		val.setNumber(7829282);
		
		System.out.println(val.getName());
		System.out.println(val.getrollNo());
		System.out.println(val.getsalary());
		System.out.println(val.getnumber());
	}

	
}
